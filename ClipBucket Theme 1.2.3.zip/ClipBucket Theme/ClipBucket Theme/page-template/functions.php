<?php
// Register Video Post Type
function clipbucket_register_post_type() {
    register_post_type('video', array(
        'labels' => array(
            'name' => 'Videos',
            'singular_name' => 'Video',
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-video-alt3',
    ));
}
add_action('init', 'clipbucket_register_post_type');

// Register Navigation Menu
function clipbucket_register_menu() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'clipbucket-theme'),
    ));
}
add_action('init', 'clipbucket_register_menu');
?>
