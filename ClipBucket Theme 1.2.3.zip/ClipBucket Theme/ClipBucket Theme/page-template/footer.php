<footer>
    <p>&copy; <?php echo date('Y'); ?> - Powered by ClipBucket Theme</p>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
