<?php get_header(); ?>
<div class="container">
    <h2>Featured Videos</h2>
    <div class="featured-videos">
        <?php
        // Query for featured videos
        $featured_query = new WP_Query(array(
            'post_type' => 'video',
            'meta_key' => 'is_featured',
            'meta_value' => '1',
        ));
        if ($featured_query->have_posts()) {
            while ($featured_query->have_posts()) {
                $featured_query->the_post(); ?>
                <div class="video">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail(); ?>
                        <h3><?php the_title(); ?></h3>
                    </a>
                </div>
        <?php }
        } else {
            echo '<p>No featured videos found</p>';
        }
        wp_reset_postdata();
        ?>
    </div>

    <h2>Recent Videos</h2>
    <div class="recent-videos">
        <?php
        // Query for recent videos
        $recent_query = new WP_Query(array(
            'post_type' => 'video',
            'posts_per_page' => 5,
        ));
        if ($recent_query->have_posts()) {
            while ($recent_query->have_posts()) {
                $recent_query->the_post(); ?>
                <div class="video">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail(); ?>
                        <h3><?php the_title(); ?></h3>
                    </a>
                </div>
        <?php }
        }
        wp_reset_postdata();
        ?>
    </div>
</div>
<?php get_footer(); ?>
