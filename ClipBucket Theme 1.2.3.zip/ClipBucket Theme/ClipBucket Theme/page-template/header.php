<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $site_title; ?> - <?php echo $site_desc; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" href="<?php echo $site_url; ?>/favicon.ico" type="image/x-icon">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo $baseurl; ?>/themes/your_theme_name/css/styles.css">
    <link rel="stylesheet" href="<?php echo $baseurl; ?>/themes/your_theme_name/css/responsive.css">
    
    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    
    <?php if($head_scripts) { echo $head_scripts; } ?>
</head>
<body>

<!-- Header Section -->
<header class="site-header">
    <div class="container">
        <div class="header-left">
            <!-- Logo -->
            <a href="<?php echo $baseurl; ?>" class="logo">
                <img src="<?php echo $baseurl; ?>/themes/your_theme_name/images/logo.png" alt="Site Logo">
            </a>
        </div>
        
        <div class="header-right">
            <!-- Search Bar -->
            <form action="<?php echo $baseurl; ?>/search" method="get" class="search-form">
                <input type="text" name="query" placeholder="Search videos..." required>
                <button type="submit">Search</button>
            </form>
            
            <!-- User Login / Logout -->
            <?php if($logged_in) { ?>
                <a href="<?php echo $baseurl; ?>/logout" class="logout-btn">Logout</a>
            <?php } else { ?>
                <a href="<?php echo $baseurl; ?>/login" class="login-btn">Login</a>
            <?php } ?>
        </div>
    </div>
</header>

<!-- Navigation Bar -->
<nav class="main-nav">
    <div class="container">
        <ul>
            <li><a href="<?php echo $baseurl; ?>">Home</a></li>
            <li><a href="<?php echo $baseurl; ?>/categories">Categories</a></li>
            <li><a href="<?php echo $baseurl; ?>/popular">Popular</a></li>
            <li><a href="<?php echo $baseurl; ?>/latest">Latest</a></li>
            <li><a href="<?php echo $baseurl; ?>/upload">Upload</a></li>
        </ul>
    </div>
</nav>

<!-- Main Content Start -->
<div class="main-content">
